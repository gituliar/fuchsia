In this directory you will find matrices which appear in real problems of physics.

  * `lee_[01,02,03].mtx` (from R.Lee)
  * `pop_01.m` (from C.Papadopoulos at LL2016)
  * `pop_02.m` same as above, but with some `ep` factored out
